import React from 'react'
import styles from '../components.module.css'
import Card from '../components/Card'
// eslint-disable-next-line no-unused-vars
import { motion } from 'framer-motion'

export default function Home() {
  return (
    <div className="container">
      <motion.section
        className={styles.hero}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: '1fr 420px',
            gap: 20,
            alignItems: 'center',
            padding: 24,
          }}
        >
          <div>
            <h1>Beautiful Landing UI — Fast to build</h1>
            <p style={{ color: 'var(--muted)' }}>
              A small, responsive example focused on structure, accessibility, and maintainability.
            </p>
            <a className="btn" href="#features">Get started</a>
          </div>

          <motion.div
            style={{
              background: 'linear-gradient(135deg, var(--primary), transparent)',
              borderRadius: 12,
              height: 220,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'white',
            }}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            Hero Image
          </motion.div>
        </div>
      </motion.section>

      <section id="features">
        <h2>Features</h2>
        <div className={styles.features} style={{ marginTop: 12 }}>
          <Card title="Accessible">Semantic HTML, labels, and keyboard-friendly UI</Card>
          <Card title="Responsive">Grid + flex layouts that adapt to mobile screens</Card>
          <Card title="Reusable">Small, focused components that can be reused</Card>
        </div>
      </section>
    </div>
  )
}
