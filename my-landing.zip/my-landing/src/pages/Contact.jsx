import React, { useState } from 'react'
import FormField from '../components/FormField'

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', message: '' })
  const [errors, setErrors] = useState({})
  const [success, setSuccess] = useState(false)

  function validate() {
    const e = {}
    if (!form.name.trim()) e.name = 'Name is required'
    if (!/^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$/.test(form.email)) e.email = 'Enter a valid email'
    if (form.message.trim().length < 10) e.message = 'Message must be 10+ characters'
    return e
  }

  function handleSubmit(ev) {
    ev.preventDefault()
    const e = validate()
    setErrors(e)
    if (Object.keys(e).length === 0) {
      setSuccess(true)
      setForm({ name: '', email: '', message: '' })
      setTimeout(() => setSuccess(false), 3000)
    }
  }

  return (
    <div className="container">
      <h1>Contact</h1>
      <form onSubmit={handleSubmit} noValidate style={{ maxWidth: 640 }}>
        <FormField label="Name" id="name">
          <input id="name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} style={{ width: '100%', padding: 8, borderRadius: 8 }} />
          {errors.name && <div style={{ color: 'crimson' }}>{errors.name}</div>}
        </FormField>

        <FormField label="Email" id="email">
          <input id="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} style={{ width: '100%', padding: 8, borderRadius: 8 }} />
          {errors.email && <div style={{ color: 'crimson' }}>{errors.email}</div>}
        </FormField>

        <FormField label="Message" id="message">
          <textarea id="message" value={form.message} onChange={e => setForm({ ...form, message: e.target.value })} rows={6} style={{ width: '100%', padding: 8, borderRadius: 8 }} />
          {errors.message && <div style={{ color: 'crimson' }}>{errors.message}</div>}
        </FormField>

        <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
          <button className="btn" type="submit">Send</button>
          {success && <span style={{ color: 'green' }}>Message sent (demo)</span>}
        </div>
      </form>
    </div>
  )
}
