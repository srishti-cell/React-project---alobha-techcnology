import React from 'react'
import styles from '../components.module.css'

export default function Footer() {
  return (
    <footer className={styles.footer}>
      <div className="container">
        <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}>
          <div>
            <strong>MyLanding</strong>
            <div style={{ color: 'var(--muted)' }}>
              Small responsive landing UI — built with React
            </div>
          </div>
          <div style={{ color: 'var(--muted)' }}>Contact: hello@example.com</div>
        </div>
      </div>
    </footer>
  )
}
