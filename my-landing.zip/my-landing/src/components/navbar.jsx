import React from 'react'
import { NavLink } from 'react-router-dom'
import styles from '../components.module.css'
import ThemeToggle from './ThemeToggle'

export default function Navbar() {
  return (
    <header className={styles.nav}>
      <div className={`container ${styles.navInner}`}>
        <div className="brand">MyLanding</div>
        <nav className={styles.navLinks} aria-label="Main navigation">
          <NavLink to="/" end>Home</NavLink>
          <NavLink to="/about">About</NavLink>
          <NavLink to="/contact">Contact</NavLink>
        </nav>
        <ThemeToggle />
      </div>
    </header>
  )
}
