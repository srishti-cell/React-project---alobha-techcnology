import React from 'react'
import styles from '../components.module.css'

export default function Card({ title, children }) {
  return (
    <article className={styles.card}>
      <h3>{title}</h3>
      <p>{children}</p>
    </article>
  )
}
