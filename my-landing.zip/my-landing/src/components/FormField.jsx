import React from 'react'

export default function FormField({ label, id, children }) {
  return (
    <div style={{ marginBottom: 12 }}>
      <label htmlFor={id} style={{ display: 'block', marginBottom: 6 }}>{label}</label>
      {children}
    </div>
  )
}
