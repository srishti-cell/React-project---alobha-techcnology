import React from 'react'

export default function About() {
  return (
    <div className="container">
      <section style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: 20, alignItems: 'start' }}>
        <div>
          <h1>About this project</h1>
          <p style={{ color: 'var(--muted)' }}>
            This is a compact starter demonstrating routing, accessibility, and responsive design.
          </p>
        </div>
        <aside style={{ background: 'var(--card)', padding: 16, borderRadius: 12 }}>
          <img src="/src/assets/hero.jpg" alt="Decorative" style={{ width: '100%', borderRadius: 8 }} />
        </aside>
      </section>

      <section style={{ marginTop: 20 }}>
        <h2>Tech</h2>
        <ul>
          <li>React + Vite</li>
          <li>React Router v6</li>
          <li>CSS Modules & variables</li>
          <li>Framer Motion</li>
        </ul>
      </section>
    </div>
  )
}
